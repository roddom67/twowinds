<?php

/* 
 * titulo Banner Disponibilidad 
 *
 ***/

	
	$bannerDisponibilidad = array(
		'imagen' => 'images/disponibilidad/disponibilidad.jpg',
		'tituloImg' => 'Disponiblidad',
		'titulo' => 'Encontrá un departamento a <br>tu medida',
		'link' => array(
			'href' => '#',
			'title' => 'Disponibilidad'
		)				
	);

	

?>