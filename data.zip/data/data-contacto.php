<?php

/* 
 * titulo CONTACTO
 *
 ***/
	$pagina = 'contacto';
	$proyecto = 'twowinds';
	$activoC = true;
	
	$headTitulo[$pagina]='Contacto | Two Winds | Urquiza';
	$headDesc[$pagina]='Two Winds - Urquiza. Mi lugar en el mundo. 54 11 5354.8000';
	$headKeywords[$pagina] = 'barrancas, barrio, luminosos, ambientees, edificio, moderno, ciudad, departamentos, inmobiliaria, arquitecto, desarrollo, gestión, inmobiliarios, gerenciamiento,edificios, vivienda, oficinas, concursos, construcción, planificación, obras, dirección, urquiza, two winds';
	
	$textoDestacado = array (
		"titulo" => "Contacto",
		"subtitulo" => "In hac habitasse platea dictumst. <br>Quisque lorem arcu, laoreet vel <br>bibendum sed, vulputate non eros."
	);
	
	$informacion = array(
		'titulo' => 'Información',
		'texto' => 'Sales Center<br>Holberg 1770<br>T. (+5411) 5354.8000<br>Buenos Aires, Argentina',
		'mapa' => 'images/contacto/mapa.png'
	);

?>