<?php

/* 
 * titulo AMENITIES
 *
 ***/
	$pagina = 'el-equipo';
	$proyecto = 'twowinds';
	$activoEE = true;
	
	$headTitulo[$pagina]='El Equipo | Two Winds | Urquiza';
	$headDesc[$pagina]='Two Winds - Urquiza. Mi lugar en el mundo. 54 11 5354.8000';
	$headKeywords[$pagina] = 'barrancas, barrio, luminosos, ambientees, edificio, moderno, ciudad, departamentos, inmobiliaria, arquitecto, desarrollo, gestión, inmobiliarios, gerenciamiento,edificios, vivienda, oficinas, concursos, construcción, planificación, obras, dirección, urquiza, two winds';
	
	$textoDestacado = array (
		"titulo" => "El desarrollador",
		"logo" => array(
			"imagen" => "images/elEquipo/logo-empresa.png",
			"titulo" => "Empresa"
		),
		"subtitulo" => "Desarrollamos <br>proyectos de vida",
		'texto' => 'Nullam venenatis tristique leo, vitae finibus leo aliquam a. Integer egestas quam eget diam dignissim tempus. Vivamus ut porta arcu, aliquam convallis tortor. Praesent rutrum pellentesque lobortis. In vitae ligula sit amet nibh aliquet maximus. Fusce interdum dictum enim, vel vehicula augue ultricies eu. Integer vulputate mauris quis volutpat sollicitudin. Pellentesque aliquet felis ex, ac accumsan libero tristique a. Aliquam scelerisque, urna et rutrum porttitor, lectus neque rutrum est, sed consequat libero augue a ligula.',
		'link' => array(
			'href' =>'#',
			'title' => 'Visitar web'
		)
	);


?>