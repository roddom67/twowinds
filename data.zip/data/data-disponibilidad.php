<?php

/* 
 * titulo DISPONIBILIDAD
 *
 ***/
	$pagina = 'disponibilidad';
	$proyecto = 'twowinds';
	$activoD = true;
	
	$headTitulo[$pagina]='Disponibilidad | Two Winds | Urquiza';
	$headDesc[$pagina]='Two Winds - Urquiza. Mi lugar en el mundo. 54 11 5354.8000';
	$headKeywords[$pagina] = 'barrancas, barrio, luminosos, ambientees, edificio, moderno, ciudad, departamentos, inmobiliaria, arquitecto, desarrollo, gestión, inmobiliarios, gerenciamiento,edificios, vivienda, oficinas, concursos, construcción, planificación, obras, dirección, urquiza, two winds';
	
	$textoDestacado = array (
		"titulo" => "Disponibilidad",
		"subtitulo" => "El confort deseado",
		'texto' => 'TwoWinds Urquiza ofrece toda clase de <br>comodidades pensadas especialmente para <br>hacer más sencillas las experiencias del <br>mundo moderno.'
	);
	
	

?>