<?php

/* 
 * titulo Banner Disponibilidad 
 *
 ***/

	
	$navSections = array(
		array(
			'imagen' => 'images/barrio/galeria1.jpg',
			'tituloImg' => 'El Barrio',
			'parrafo' => 'El barrio vestibulum maximus arcu vel',
			'link' => array(
				'href' => 'el-barrio.php',
				'title' => 'El Barrio'
			)
		),
		array(
			'imagen' => 'images/unidades/galeria1.jpg',
			'tituloImg' => 'Unidades',
			'parrafo' => 'Unidades vestibulum maximus arcu vel',
			'link' => array(
				'href' => 'unidades.php',
				'title' => 'Unidades'
			)
		),
		array(
			'imagen' => 'images/amenities/galeria1.jpg',
			'tituloImg' => 'Amenities',
			'parrafo' => 'Amenities vestibulum maximus arcu vel',
			'link' => array(
				'href' => 'amenities.php',
				'title' => 'Amenities'
			)
		)
	);

	

?>